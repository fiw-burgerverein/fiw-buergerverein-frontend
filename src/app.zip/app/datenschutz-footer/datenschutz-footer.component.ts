import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datenschutz-footer',
  templateUrl: './datenschutz-footer.component.html',
  styleUrls: ['./datenschutz-footer.component.css']
})
export class DatenschutzFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
